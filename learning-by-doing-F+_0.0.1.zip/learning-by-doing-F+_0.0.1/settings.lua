data:extend({
    {
        type = "double-setting",
        name = "tech-crafting-requirement-multiplier",
        setting_type = "startup",
        minimum_value = 0.01,
		maximum_value = 1000.0,
        default_value = 1.0,
		order = "a"
    }
})